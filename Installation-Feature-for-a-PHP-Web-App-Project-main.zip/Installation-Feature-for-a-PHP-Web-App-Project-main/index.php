<?php 
// Include DotEnvironment Class
require_once('./config.php');


?>