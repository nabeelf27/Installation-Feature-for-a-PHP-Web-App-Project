<div class="container-fluid py-0">
    <div class="col-lg-6 col-md-8 col-sm-12 col-xs-12 mx-auto mt-3">
        <div class="card rounded-0">
            <div class="card-header rounded-0">
                <div class="card-title"><b>Site Installation</b></div>
            </div>
            <div class="card-body">
                <div class="container-fluid">
                    <p>Please Fill the proceeding form fields to complete the setup or installation of this site.</p>
                </div>
            </div>
            <div class="card-footer text-end">
                <a href="./?step=1" class="btn btn-primary">Proceed</a>
            </div>
        </div>
    </div>
</div>